<?php
$user = current_user();
$flash = get_flash();
$pageTitle = $pageTitle ?? 'Dashboard';
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> · LENDORA</title>
<link rel="stylesheet" href="<?= e(url('assets/css/app.css')) ?>">
<script defer src="<?= e(url('assets/js/app.js')) ?>"></script>
</head><body>
<div class="app-shell">
<aside class="sidebar" id="sidebar">
<a class="brand" href="<?= e(url($user ? dashboard_path() : 'index.php')) ?>"><span class="brand-mark">L</span><span>LENDORA<small>FINANCIAL SERVICES</small></span></a>
<?php if ($user): ?>
<div class="nav-label">WORKSPACE</div>
<nav>
<?php
$nav = match($user['role']) {
'admin' => [['admin/index.php','grid-2x2','Overview'],['admin/applications.php','file-text','Applications'],['admin/loans.php','wallet','Loan portfolio'],['admin/customers.php','users','Customers'],['admin/products.php','layers','Loan products'],['admin/repayments.php','credit-card','Repayments'],['admin/reports.php','chart-no-axes-combined','Reports']],
'officer' => [['officer/index.php','grid-2x2','Overview'],['officer/applications.php','file-text','Applications'],['officer/loans.php','wallet','Loans']],
default => [['customer/index.php','grid-2x2','Overview'],['customer/apply.php','plus-circle','Apply for a loan'],['customer/loans.php','wallet','My loans'],['customer/profile.php','user-round','My profile']]
};
foreach ($nav as [$href,$icon,$label]): ?>
<a class="nav-link <?= str_contains($_SERVER['PHP_SELF'], basename($href)) ? 'active' : '' ?>" href="<?= e(url($href)) ?>"><span class="nav-icon"><?= e(strtoupper(substr($label,0,1))) ?></span><?= e($label) ?></a>
<?php endforeach; ?>
</nav>
<div class="sidebar-bottom"><div class="avatar"><?= e(strtoupper(substr($user['full_name'],0,1))) ?></div><div class="user-mini"><strong><?= e($user['full_name']) ?></strong><small><?= e(ucfirst($user['role'])) ?></small></div><a class="logout-link" href="<?= e(url('logout.php')) ?>">↗</a></div>
<?php else: ?><nav><a class="nav-link" href="<?= e(url('login.php')) ?>">Sign in</a><a class="nav-link" href="<?= e(url('register.php')) ?>">Create account</a></nav><?php endif; ?>
</aside>
<main class="main-area">
<header class="topbar"><button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">☰</button><div><span class="eyebrow">LENDING MANAGEMENT</span><h1><?= e($pageTitle) ?></h1></div><div class="topbar-right"><?php if($user): ?><span class="currency-chip">ZMW&nbsp; / &nbsp;USD</span><span class="avatar small"><?= e(strtoupper(substr($user['full_name'],0,1))) ?></span><?php endif; ?></div></header>
<div class="content">
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
