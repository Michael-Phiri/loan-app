CREATE DATABASE IF NOT EXISTS lendora CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lendora;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS audit_logs, repayment_schedule, repayments, loans, loan_applications, loan_products, users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(40) NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','officer','customer') NOT NULL DEFAULT 'customer',
 status ENUM('active','suspended','inactive') NOT NULL DEFAULT 'active',
 created_at DATETIME NOT NULL,
 updated_at DATETIME NULL,
 INDEX idx_users_role_status(role,status)
) ENGINE=InnoDB;

CREATE TABLE loan_products (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 loan_type ENUM('personal','business') NOT NULL,
 description TEXT NULL,
 min_amount DECIMAL(15,2) NOT NULL,
 max_amount DECIMAL(15,2) NOT NULL,
 annual_rate DECIMAL(7,4) NOT NULL,
 fee DECIMAL(15,2) NOT NULL DEFAULT 0,
 min_term_months SMALLINT UNSIGNED NOT NULL,
 max_term_months SMALLINT UNSIGNED NOT NULL,
 currencies VARCHAR(20) NOT NULL DEFAULT 'ZMW,USD',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE loan_applications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 loan_type ENUM('personal','business') NOT NULL,
 amount DECIMAL(15,2) NOT NULL,
 currency CHAR(3) NOT NULL,
 term_months SMALLINT UNSIGNED NOT NULL,
 purpose TEXT NOT NULL,
 status ENUM('pending','under_review','approved','rejected','disbursed') NOT NULL DEFAULT 'pending',
 review_note TEXT NULL,
 reviewed_by BIGINT UNSIGNED NULL,
 reviewed_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 CONSTRAINT fk_app_user FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT fk_app_product FOREIGN KEY(product_id) REFERENCES loan_products(id),
 CONSTRAINT fk_app_reviewer FOREIGN KEY(reviewed_by) REFERENCES users(id),
 INDEX idx_app_status(status,created_at)
) ENGINE=InnoDB;

CREATE TABLE loans (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 loan_number VARCHAR(40) NOT NULL UNIQUE,
 application_id BIGINT UNSIGNED NOT NULL UNIQUE,
 user_id BIGINT UNSIGNED NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 principal DECIMAL(15,2) NOT NULL,
 fee DECIMAL(15,2) NOT NULL DEFAULT 0,
 annual_rate DECIMAL(7,4) NOT NULL,
 currency CHAR(3) NOT NULL,
 term_months SMALLINT UNSIGNED NOT NULL,
 monthly_payment DECIMAL(15,2) NOT NULL,
 outstanding_balance DECIMAL(15,2) NOT NULL,
 status ENUM('disbursed','active','paid','overdue','defaulted') NOT NULL DEFAULT 'disbursed',
 disbursed_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NULL,
 CONSTRAINT fk_loan_application FOREIGN KEY(application_id) REFERENCES loan_applications(id),
 CONSTRAINT fk_loan_user FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT fk_loan_product FOREIGN KEY(product_id) REFERENCES loan_products(id),
 INDEX idx_loan_user_status(user_id,status),
 INDEX idx_loan_currency_status(currency,status)
) ENGINE=InnoDB;

CREATE TABLE repayment_schedule (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 loan_id BIGINT UNSIGNED NOT NULL,
 installment_no SMALLINT UNSIGNED NOT NULL,
 due_date DATE NOT NULL,
 principal_due DECIMAL(15,2) NOT NULL,
 interest_due DECIMAL(15,2) NOT NULL,
 total_due DECIMAL(15,2) NOT NULL,
 balance_after DECIMAL(15,2) NOT NULL,
 status ENUM('pending','partial','paid','overdue') NOT NULL DEFAULT 'pending',
 CONSTRAINT fk_schedule_loan FOREIGN KEY(loan_id) REFERENCES loans(id),
 UNIQUE KEY uq_schedule_installment(loan_id,installment_no),
 INDEX idx_schedule_due(due_date,status)
) ENGINE=InnoDB;

CREATE TABLE repayments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 loan_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 amount DECIMAL(15,2) NOT NULL,
 currency CHAR(3) NOT NULL,
 method ENUM('cash','bank_transfer','mobile_money','other') NOT NULL,
 reference VARCHAR(100) NULL,
 received_by BIGINT UNSIGNED NOT NULL,
 received_at DATETIME NOT NULL,
 CONSTRAINT fk_repay_loan FOREIGN KEY(loan_id) REFERENCES loans(id),
 CONSTRAINT fk_repay_user FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT fk_repay_receiver FOREIGN KEY(received_by) REFERENCES users(id),
 INDEX idx_repay_date(received_at),
 INDEX idx_repay_currency(currency)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id BIGINT UNSIGNED NULL,
 details JSON NULL,
 ip_address VARCHAR(45) NULL,
 created_at DATETIME NOT NULL,
 CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_audit_entity(entity_type,entity_id),
 INDEX idx_audit_created(created_at)
) ENGINE=InnoDB;

-- Development seed users. Password for all three: ChangeMe123!
INSERT INTO users(full_name,email,phone,password_hash,role,status,created_at) VALUES
('LENDORA Administrator','admin@lendora.local','+260000000001','$2y$12$lVZnn2/4FKNDfs7V7awiaeJda8qFatkqudKPUEVxS6up4NRIzYjoa','admin','active',NOW()),
('Loan Officer','officer@lendora.local','+260000000002','$2y$12$lVZnn2/4FKNDfs7V7awiaeJda8qFatkqudKPUEVxS6up4NRIzYjoa','officer','active',NOW()),
('Demo Customer','customer@lendora.local','+260000000003','$2y$12$lVZnn2/4FKNDfs7V7awiaeJda8qFatkqudKPUEVxS6up4NRIzYjoa','customer','active',NOW());

INSERT INTO loan_products(name,loan_type,description,min_amount,max_amount,annual_rate,fee,min_term_months,max_term_months,currencies,is_active,created_at) VALUES
('Personal Flex Loan','personal','Illustrative unsecured personal lending product.',500,50000,24.0000,50,3,24,'ZMW,USD',1,NOW()),
('Business Growth Loan','business','Illustrative working-capital and business growth product.',5000,500000,18.0000,150,6,36,'ZMW,USD',1,NOW()),
('Emergency Support Loan','personal','Illustrative short-term emergency financing.',300,10000,30.0000,25,1,12,'ZMW',1,NOW());
