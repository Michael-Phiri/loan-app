<?php
declare(strict_types=1);
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function require_role(array $roles): void {
    require_login();
    if (!in_array(current_user()['role'], $roles, true)) { http_response_code(403); exit('Access denied.'); }
}
function login_user(string $email, string $password): bool {
    $stmt = db()->prepare('SELECT id, full_name, email, password_hash, role, status FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([strtolower(trim($email))]);
    $user = $stmt->fetch();
    if (!$user || $user['status'] !== 'active' || !password_verify($password, $user['password_hash'])) return false;
    session_regenerate_id(true);
    unset($user['password_hash'], $user['status']);
    $_SESSION['user'] = $user;
    audit('login', 'user', (int)$user['id']);
    return true;
}
function logout_user(): void {
    if (current_user()) audit('logout', 'user', (int)current_user()['id']);
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time()-42000, $p['path'], '', $p['secure'], $p['httponly']);
    }
    session_destroy();
}
function dashboard_path(): string {
    return match(current_user()['role'] ?? '') {
        'admin' => 'admin/index.php',
        'officer' => 'officer/index.php',
        default => 'customer/index.php'
    };
}
