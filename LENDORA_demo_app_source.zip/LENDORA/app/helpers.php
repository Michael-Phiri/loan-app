<?php
declare(strict_types=1);
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = ''): string { return rtrim(APP_URL, '/') . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function money(float|string $amount, string $currency): string {
    return ($currency === 'USD' ? '$' : 'K') . number_format((float)$amount, 2);
}
function flash(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type, 'message'=>$message]; }
function get_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf'] ?? '', $token)) {
            http_response_code(419); exit('Your session token expired. Refresh the page and try again.');
        }
    }
}
function audit(string $action, string $entity, ?int $entityId = null, array $details = []): void {
    try {
        $stmt = db()->prepare('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())');
        $stmt->execute([$_SESSION['user']['id'] ?? null, $action, $entity, $entityId, json_encode($details), $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Throwable $e) { error_log('Audit write failed: ' . $e->getMessage()); }
}
function input(string $key, int $max = 255): string {
    $v = trim((string)($_POST[$key] ?? ''));
    return mb_substr($v, 0, $max);
}
function valid_currency(string $currency): bool { return in_array($currency, ['ZMW','USD'], true); }
function status_badge(string $status): string {
    $class = match($status) {
        'approved','disbursed','paid','active' => 'success',
        'rejected','defaulted','overdue' => 'danger',
        'pending','under_review' => 'warning',
        default => 'muted'
    };
    return '<span class="badge badge-' . $class . '">' . e(ucwords(str_replace('_',' ',$status))) . '</span>';
}
