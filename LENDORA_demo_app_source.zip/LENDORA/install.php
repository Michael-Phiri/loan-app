<?php
require_once __DIR__.'/app/bootstrap.php';
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $name=input('name');$email=strtolower(input('email'));$pass=(string)($_POST['password']??'');
 if(strlen($pass)<12||!filter_var($email,FILTER_VALIDATE_EMAIL)) $msg='Use a valid email and password of at least 12 characters.';
 else { $q=db()->prepare("INSERT INTO users(full_name,email,password_hash,role,status,created_at) VALUES(?,?,?,'admin','active',NOW())");$q->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);$msg='Admin created. Delete install.php now, then sign in.'; }
}
?><!doctype html><html><head><meta charset="utf-8"><title>LENDORA setup</title><link rel="stylesheet" href="<?= e(url('assets/css/app.css')) ?>"></head><body class="auth-page"><main class="auth-main"><form class="auth-card" method="post"><h2>Initial administrator setup</h2><p>Run once after importing the schema. Remove this file afterwards.</p><?php if($msg): ?><div class="alert alert-info"><?= e($msg) ?></div><?php endif; ?><?= csrf_field() ?><label>Administrator name<input name="name" required></label><label>Email<input name="email" type="email" required></label><label>Password (12+ characters)<input name="password" type="password" minlength="12" required></label><button class="btn btn-primary btn-block">Create administrator</button></form></main></body></html>