Development upload directory. For production, move files outside public web root and implement private file serving.
