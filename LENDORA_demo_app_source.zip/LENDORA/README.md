# LENDORA — Lending Management Platform

A PHP 8.1+ / MySQL 8 full-stack lending application for personal and business lending, with ZMW and USD support.

## Included
- Customer registration, login, profile and dashboard
- Personal and business loan applications
- Configurable loan products, interest rates, fees, terms and currency
- Officer application review and approve/reject workflow
- Admin dashboard, user management, product management and reporting
- Loan disbursement recording, repayment posting and amortisation schedules
- Separate currency ledgers (ZMW and USD are never silently combined)
- CSRF protection, password hashing, prepared statements, role checks, audit events
- Responsive UI and demo seed data

## Requirements
- PHP 8.1+ (extensions: pdo_mysql, mbstring, fileinfo, openssl)
- MySQL 8.0+ or MariaDB 10.5+
- Apache with mod_rewrite (optional; the app also works from its folder URL)

## Installation (XAMPP)
1. Copy the `LENDORA` folder into `C:\xampp\htdocs\`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/schema.sql`.
4. Edit `config/config.php` with your database credentials and a long random `APP_KEY`.
5. Visit `http://localhost/LENDORA/install.php` once to create the initial admin account, or use the seeded demo accounts below.
6. For a clean setup, remove `install.php` after installation.
7. Visit `http://localhost/LENDORA/`.

## Demo accounts
After importing the schema, the seed script creates:
- Admin: `admin@lendora.local` / `ChangeMe123!`
- Officer: `officer@lendora.local` / `ChangeMe123!`
- Customer: `customer@lendora.local` / `ChangeMe123!`

Change all demo passwords immediately. Demo data is illustrative only.

## Important configuration
- Set `APP_ENV` to `production` and `APP_DEBUG` to `false` on a live server.
- Use HTTPS, secure cookies, a non-root database account, private upload storage and scheduled encrypted backups.
- Do not expose `uploads/` directly on a public production server. Configure a private storage directory.
- Set the correct company details, lending policies, rates, fees, currencies and notification providers before launch.
- This project records disbursements and repayments internally. It does **not** move money by itself. Integrate a licensed payment provider after obtaining merchant credentials and completing sandbox/live testing.
- Loan eligibility is a configurable operational workflow, not an automated credit bureau decision.

## Currency and calculations
Loan amounts are stored in the currency selected for the loan. A ZMW loan is repaid in ZMW and a USD loan in USD. Dashboard totals are reported separately by currency. No exchange-rate conversion is assumed.

Interest uses a reducing-balance amortisation schedule with a nominal annual rate converted to a monthly rate. Fees are recorded separately. The schedule is generated at approval/disbursement; review all terms before accepting a real application.

## Security and deployment checklist
- Replace demo credentials and APP_KEY.
- Configure HTTPS and secure session cookies.
- Disable public access to install.php after setup.
- Restrict uploads, set file-size limits and scan uploaded documents.
- Configure database backups, monitoring, logging and access reviews.
- Add MFA, rate limiting, email/SMS delivery and payment-provider webhooks before production.
- Obtain legal/compliance review for Zambian lending, consumer disclosures, AML/KYC, data protection and any applicable licensing obligations.

## Project structure
- `app/` application services, auth, database and helpers
- `admin/`, `officer/`, `customer/` role-specific portals
- `assets/` CSS and JavaScript
- `database/` schema and seed data
- `includes/` shared page layout
- `uploads/` local development document storage
