<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/config/database.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
function out(int $code, array $data): never { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_SLASHES); exit; }
function body(): array { $raw=file_get_contents('php://input'); $data=json_decode($raw ?: '{}', true); return is_array($data)?$data:[]; }
function auth_user(): array {
 $header=$_SERVER['HTTP_AUTHORIZATION'] ?? '';
 if (!preg_match('/Bearer\s+([A-Fa-f0-9]{64})/', $header, $m)) out(401,['error'=>'Authentication required']);
 $q=db()->prepare('SELECT u.id,u.full_name,u.email,u.phone,u.role,u.status FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>NOW() LIMIT 1');
 $q->execute([hash('sha256',$m[1])]); $u=$q->fetch();
 if (!$u || $u['status']!=='active' || $u['role']!=='customer') out(401,['error'=>'Session expired or account unavailable']);
 return $u;
}
try {
 $action=(string)($_GET['action'] ?? '');
 if ($action==='login' && $_SERVER['REQUEST_METHOD']==='POST') {
  $b=body(); $email=filter_var($b['email']??'',FILTER_VALIDATE_EMAIL); $password=(string)($b['password']??'');
  if (!$email || strlen($password)<8) out(422,['error'=>'Enter a valid email and password']);
  $q=db()->prepare("SELECT id,full_name,email,phone,password_hash,role,status FROM users WHERE email=? LIMIT 1"); $q->execute([$email]); $u=$q->fetch();
  if (!$u || !password_verify($password,$u['password_hash']) || $u['role']!=='customer' || $u['status']!=='active') out(401,['error'=>'Invalid customer credentials']);
  $token=bin2hex(random_bytes(32)); $ins=db()->prepare('INSERT INTO api_tokens(user_id,token_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 14 DAY),NOW())'); $ins->execute([$u['id'],hash('sha256',$token)]);
  unset($u['password_hash']); out(200,['token'=>$token,'user'=>$u,'mode'=>'demo']);
 }
 if ($action==='logout' && $_SERVER['REQUEST_METHOD']==='POST') { $u=auth_user(); $h=$_SERVER['HTTP_AUTHORIZATION']??''; preg_match('/Bearer\s+([A-Fa-f0-9]{64})/',$h,$m); db()->prepare('DELETE FROM api_tokens WHERE token_hash=?')->execute([hash('sha256',$m[1])]); out(200,['message'=>'Signed out']); }
 $u=auth_user();
 if ($action==='me') out(200,['user'=>$u,'mode'=>'demo']);
 if ($action==='dashboard') {
  $q=db()->prepare("SELECT COUNT(*) total, COALESCE(SUM(outstanding_balance),0) outstanding FROM loans WHERE user_id=? AND status IN ('disbursed','active','overdue')"); $q->execute([$u['id']]); $loan=$q->fetch();
  $q=db()->prepare("SELECT COUNT(*) total FROM loan_applications WHERE user_id=?"); $q->execute([$u['id']]); $apps=$q->fetch();
  out(200,['user'=>$u,'active_loans'=>(int)$loan['total'],'outstanding'=>(string)$loan['outstanding'],'applications'=>(int)$apps['total'],'currency'=>'ZMW','mode'=>'demo']);
 }
 if ($action==='products') { $q=db()->query('SELECT id,name,loan_type,description,min_amount,max_amount,annual_rate,fee,min_term_months,max_term_months,currencies FROM loan_products WHERE is_active=1 ORDER BY id'); out(200,['products'=>$q->fetchAll(),'mode'=>'demo']); }
 if ($action==='loans') { $q=db()->prepare('SELECT id,loan_number,principal,fee,annual_rate,currency,term_months,monthly_payment,outstanding_balance,status,disbursed_at,created_at FROM loans WHERE user_id=? ORDER BY id DESC'); $q->execute([$u['id']]); out(200,['loans'=>$q->fetchAll(),'mode'=>'demo']); }
 if ($action==='repayments') { $q=db()->prepare('SELECT r.id,r.amount,r.currency,r.method,r.reference,r.received_at,l.loan_number FROM repayments r JOIN loans l ON l.id=r.loan_id WHERE r.user_id=? ORDER BY r.received_at DESC LIMIT 100'); $q->execute([$u['id']]); out(200,['repayments'=>$q->fetchAll(),'mode'=>'demo']); }
 if ($action==='apply') out(403,['error'=>'Loan applications are disabled in this demo build. Real lending requires adult eligibility checks, KYC, regulatory approval and a verified payment workflow.']);
 out(404,['error'=>'Unknown API action']);
} catch (Throwable $e) { error_log('LENDORA API: '.$e->getMessage()); out(500,['error'=>'Server error']); }
