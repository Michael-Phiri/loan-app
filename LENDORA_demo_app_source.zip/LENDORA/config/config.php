<?php
declare(strict_types=1);

define('APP_NAME', 'LENDORA');
define('APP_ENV', 'development'); // production on live server
define('APP_DEBUG', true);
define('APP_URL', '/LENDORA'); // change if deployed at domain root: ''
define('APP_KEY', 'CHANGE-THIS-TO-A-LONG-RANDOM-SECRET-AT-LEAST-32-CHARS');

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'lendora');
define('DB_USER', 'root');
define('DB_PASS', '');

define('UPLOAD_DIR', dirname(__DIR__) . '/uploads');
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);

if (APP_ENV === 'production') {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
