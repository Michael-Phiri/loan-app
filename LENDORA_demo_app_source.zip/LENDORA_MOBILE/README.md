# LENDORA Mobile (Flutter)

Customer-facing Flutter source for the LENDORA PHP/MySQL platform. Android is the first target; the Dart code is also suitable for iOS. This package is a **demo-mode starter**, not a production lending/payment application.

## Included
- Flutter customer app: sign-in, account dashboard, personal/business product catalogue, loan records, repayment history and profile/sign-out.
- Secure token storage using `flutter_secure_storage`.
- PHP JSON API using short-lived random bearer tokens stored as SHA-256 hashes in MySQL.
- Read-only customer data endpoints. The application endpoint is intentionally disabled; no loan application, approval, disbursement or payment can be initiated from this demo app.

## 1. Install API backend
1. Deploy the existing `LENDORA/` PHP project to a PHP 8.1+ host with MySQL and HTTPS.
2. Import `database/schema.sql` into MySQL (for a fresh installation), then configure `config/config.php` and database credentials as described in the main project README.
3. Import `api/schema.sql` into the same `lendora` database to create the API token table.
4. Ensure `/api/index.php` is reachable over HTTPS. Configure the web server to prevent directory listing and protect configuration files.
5. In `api/index.php`, replace the permissive CORS header with the exact allowed app/web origins for your deployment. Do not leave wildcard CORS on a public production service.

## 2. Create Flutter platform scaffolding
Install Flutter 3.22+ and Android Studio, then run:

```bash
flutter create --org zm.co.lendora lendora_mobile
```

Copy this package's `lib/` directory and `pubspec.yaml` over the generated project. In `android/app/src/main/AndroidManifest.xml`, ensure the manifest includes:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

Then run:

```bash
flutter pub get
flutter run --dart-define=LENDORA_API_URL=https://YOUR-DOMAIN/api/index.php
```

For an Android emulator connecting to a local development server, use the computer's emulator-reachable address (commonly `http://10.0.2.2/LENDORA/api/index.php`). For a physical phone, use your computer's LAN IP or a hosted HTTPS URL. Do not use plain HTTP in production.

## 3. Demo sign-in
The original web project's seed customer is:
- `customer@lendora.local`
- `ChangeMe123!`

Change/remove all seeded credentials before any public deployment. Admin and officer accounts cannot sign into the customer mobile API.

## API endpoints
All except login require `Authorization: Bearer <token>`:
- `POST ?action=login` — email/password, returns token and user
- `POST ?action=logout`
- `GET ?action=me`
- `GET ?action=dashboard`
- `GET ?action=products`
- `GET ?action=loans`
- `GET ?action=repayments`
- `POST ?action=apply` — deliberately returns HTTP 403 in demo mode

## Build APK
Once Flutter/Android SDK is installed and the API URL is configured:

```bash
flutter build apk --release --dart-define=LENDORA_API_URL=https://YOUR-DOMAIN/api/index.php
```

The APK will be generated at `build/app/outputs/flutter-apk/app-release.apk` in the Flutter project.

## Before real-world use
This is not a production release. It has not been built with Flutter in this environment because the Flutter SDK is unavailable here. Before deployment, commission security testing, restrict CORS, add rate limiting and login abuse controls, refresh/revoke token management, audit and monitoring, privacy/consent controls, KYC and adult eligibility checks, licensed-lender/regulatory review in Zambia, approved disclosures and contracts, repayment allocation/schedules, and a regulated payment-provider integration. Never store card/mobile-money PINs or OTPs. Do not enable real-money lending or disbursement from this demo.

## Fully offline demo mode
The app defaults to `AppConfig.demoMode = true`. It uses local sample customer, product, loan and repayment data and does not contact the PHP server. Demo login:
- Email: `customer@lendora.local`
- Password: `ChangeMe123!`

All amounts and records are fictional. Application submission, approvals, disbursements and payment processing are not available. To connect a deployed backend later, set `demoMode = false` and configure the HTTPS API URL.

## Build an APK using GitHub Actions
This package includes `.github/workflows/build-apk.yml`. Upload the `LENDORA_MOBILE` folder to a GitHub repository, open **Actions → Build LENDORA Demo APK → Run workflow**, then download the `LENDORA-demo-APK` artifact from the completed run. The workflow generates the Android platform files, analyzes the Flutter source and builds a release APK.
