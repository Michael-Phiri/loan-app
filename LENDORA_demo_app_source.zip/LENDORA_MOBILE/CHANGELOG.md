# LENDORA Mobile 1.0.0
- Initial Flutter customer app source.
- PHP bearer-token API for authenticated customer read access.
- Demo-mode guard: application submission and payment flows disabled.
