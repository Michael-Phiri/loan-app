import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() => runApp(const LendoraApp());

class LendoraApp extends StatelessWidget {
  const LendoraApp({super.key});
  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF101B35);
    const green = Color(0xFF19B887);
    return MaterialApp(
      title: 'LENDORA', debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light), scaffoldBackgroundColor: const Color(0xFFF5F7FB), appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FB), foregroundColor: navy, elevation: 0), cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))), inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16))),
      home: const LoginScreen(),
    );
  }
}
