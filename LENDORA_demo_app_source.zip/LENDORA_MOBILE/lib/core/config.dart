class AppConfig {
  // Set this to your hosted LENDORA installation, ending in /api/index.php.
  // Android emulator can reach a local computer with http://10.0.2.2/...
  static const apiBaseUrl = String.fromEnvironment(
    'LENDORA_API_URL',
    defaultValue: 'https://YOUR-DOMAIN.example/api/index.php',
  );
  static const demoMode = true;
}
