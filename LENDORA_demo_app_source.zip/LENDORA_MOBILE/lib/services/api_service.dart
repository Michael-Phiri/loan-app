import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../core/config.dart';

class ApiService {
  static const _storage = FlutterSecureStorage();
  static Future<String?> get token => _storage.read(key: 'lendora_token');
  static Future<void> saveToken(String value) => _storage.write(key: 'lendora_token', value: value);
  static Future<void> clearToken() => _storage.delete(key: 'lendora_token');

  static Uri _uri(String action) => Uri.parse('${AppConfig.apiBaseUrl}?action=$action');
  static Future<Map<String, dynamic>> _request(String action, {Map<String, dynamic>? data, bool authenticated = true}) async {
    final headers = <String, String>{'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (authenticated) {
      final t = await token;
      if (t != null) headers['Authorization'] = 'Bearer $t';
    }
    final response = data == null
        ? await http.get(_uri(action), headers: headers).timeout(const Duration(seconds: 20))
        : await http.post(_uri(action), headers: headers, body: jsonEncode(data)).timeout(const Duration(seconds: 20));
    final decoded = jsonDecode(response.body);
    final result = decoded is Map<String, dynamic> ? decoded : <String, dynamic>{};
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(result['error'] ?? 'Request failed (${response.statusCode})');
    }
    return result;
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    if (AppConfig.demoMode) {
      if (email.trim().toLowerCase() != 'customer@lendora.local' || password != 'ChangeMe123!') {
        throw Exception('Use the prefilled demo customer credentials.');
      }
      await saveToken('local-demo-session');
      return {'user': _demoUser, 'token': 'local-demo-session'};
    }
    final result = await _request('login', data: {'email': email, 'password': password}, authenticated: false);
    await saveToken(result['token'] as String);
    return result;
  }
  static final Map<String, dynamic> _demoUser = {
    'id': 1001, 'full_name': 'Demo Customer', 'email': 'customer@lendora.local',
  };
  static Future<Map<String, dynamic>> dashboard() async {
    if (AppConfig.demoMode) return {
      'user': _demoUser, 'outstanding': 12500.00, 'active_loans': 1, 'applications': 2,
    };
    return _request('dashboard');
  }
  static Future<List<dynamic>> products() async {
    if (AppConfig.demoMode) return [
      {'id': 1, 'name': 'Personal Flex', 'loan_type': 'personal', 'description': 'Illustrative short-term personal finance product for the demo.', 'currencies': 'ZMW', 'min_amount': '1000', 'max_amount': '15000', 'annual_rate': '18', 'min_term_months': 3, 'max_term_months': 12, 'fee': 'Sample fee'},
      {'id': 2, 'name': 'Business Growth', 'loan_type': 'business', 'description': 'Illustrative working-capital product for small-business scenarios.', 'currencies': 'ZMW / USD', 'min_amount': '5000', 'max_amount': '50000', 'annual_rate': '16', 'min_term_months': 6, 'max_term_months': 24, 'fee': 'Sample fee'},
      {'id': 3, 'name': 'USD Starter', 'loan_type': 'personal', 'description': 'Sample USD-denominated product for interface demonstration.', 'currencies': 'USD', 'min_amount': '100', 'max_amount': '1000', 'annual_rate': '15', 'min_term_months': 3, 'max_term_months': 12, 'fee': 'Sample fee'},
    ];
    return (await _request('products'))['products'] as List<dynamic>;
  }
  static Future<List<dynamic>> loans() async {
    if (AppConfig.demoMode) return [
      {'loan_number': 'DEMO-LN-0001', 'status': 'illustrative', 'currency': 'ZMW', 'outstanding_balance': '12500.00', 'principal': '15000.00', 'term_months': 12},
    ];
    return (await _request('loans'))['loans'] as List<dynamic>;
  }
  static Future<List<dynamic>> repayments() async {
    if (AppConfig.demoMode) return [
      {'loan_number': 'DEMO-LN-0001', 'method': 'Sample record', 'received_at': '2026-10-15', 'currency': 'ZMW', 'amount': '2500.00'},
      {'loan_number': 'DEMO-LN-0001', 'method': 'Sample record', 'received_at': '2026-09-15', 'currency': 'ZMW', 'amount': '2500.00'},
    ];
    return (await _request('repayments'))['repayments'] as List<dynamic>;
  }
  static Future<void> logout() async {
    if (!AppConfig.demoMode) { try { await _request('logout', data: {}); } finally { await clearToken(); } }
    else { await clearToken(); }
  }
}
