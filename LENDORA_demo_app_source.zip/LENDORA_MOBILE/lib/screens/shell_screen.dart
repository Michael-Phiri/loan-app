import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'products_screen.dart';
import 'loans_screen.dart';
import 'profile_screen.dart';
import 'repayments_screen.dart';

class ShellScreen extends StatefulWidget { const ShellScreen({super.key}); @override State<ShellScreen> createState()=>_ShellScreenState(); }
class _ShellScreenState extends State<ShellScreen>{int index=0; final pages=const [HomeScreen(),ProductsScreen(),LoansScreen(),RepaymentsScreen(),ProfileScreen()];
 @override Widget build(BuildContext context)=>Scaffold(body:IndexedStack(index:index,children:pages),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const [NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'Home'),NavigationDestination(icon:Icon(Icons.layers_outlined),label:'Products'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),label:'Loans'),NavigationDestination(icon:Icon(Icons.payments_outlined),label:'Payments'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile')]));}
